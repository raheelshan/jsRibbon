# jsRibbon
Declerative UI library
