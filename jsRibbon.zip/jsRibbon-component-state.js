(function () {

    function resolveBindingKey(binding) {
        if (!binding) return null;

        if (typeof binding === 'string') return binding;
        if (binding.type === 'ident') return binding.name;
        if (binding.type === 'raw') return binding.raw;
        if (binding.type === 'literal') return binding.value;
        return null;
    }

    function resolveBindingValue(el, key, state) {
        let ctxEl = el.closest("[data-context-owner]");
        if (ctxEl && ctxEl._contextKey) {
            let ctxKey = ctxEl._contextKey;
            return state[ctxKey]?.[key];
        }
        return state[key];
    }

    function exportBinding(bindings, el, bindingsMap, initialStateForComponent) {
        if (bindings.export) {
            try {
                const exportStr = bindings.export.trim().replace(/^\[|\]$/g, '');
                const pairs = exportStr.split(',').map(p => p.trim()).filter(Boolean);

                let exportMap = {};
                let hasWildcard = false;

                pairs.forEach(pair => {
                    if (pair === "*") {
                        hasWildcard = true;
                        return;
                    }
                    let [from, to] = pair.split(/\s*(?:=>|as)\s*/).map(x => x.trim());
                    if (!to) to = from; // alias optional
                    exportMap[from] = to;
                });

                bindingsMap.push({
                    el,
                    type: "export",
                    exportMap,
                    hasWildcard,   // 🔑 track if * was used
                    bindings
                });
            } catch (e) {
                console.warn("Invalid export binding:", bindings.export, e);
            }
        }
    }

    function applyExport(data, state, initialState) {
        if (data.type !== "export") return;

        const { el, exportMap, hasWildcard } = data;

        const parentKey = el.closest("[data-with-owner]")?.getAttribute("data-with-owner");
        if (!parentKey) return;

        const parentObj = initialState[parentKey];
        if (!parentObj) return;

        let finalMap = { ...exportMap };

        // expand wildcard
        if (hasWildcard) {
            Object.keys(state).forEach(childProp => {
                if (!(childProp in finalMap)) {
                    finalMap[childProp] = childProp;
                }
            });
        }

        // define getters/setters
        Object.entries(finalMap).forEach(([childProp, parentProp]) => {
            if (Object.prototype.hasOwnProperty.call(parentObj, parentProp)) return;

            Object.defineProperty(parentObj, parentProp, {
                get: () => state[childProp],
                set: (val) => { state[childProp] = val; },
                enumerable: true,
                configurable: true
            });
        });
    }

    // --- helpers: find contexts up the DOM tree ---
    function findAncestorContexts(el) {
        const contexts = [];
        let cur = el;
        while (cur) {
            if (cur._context && cur._context.state) contexts.push(cur._context);
            cur = cur.parentElement;
        }
        return contexts; // nearest first
    }

    function findAncestorContextByName(el, ctxName) {
        let cur = el;
        while (cur) {
            if (cur._context && cur._context.key === ctxName) return cur._context;
            cur = cur.parentElement;
        }
        return null;
    }

    // support nested dot-paths: "cart.items.0.name"
    function getByPath(obj, pathParts) {
        return pathParts.reduce((acc, p) => (acc == null ? undefined : acc[p]), obj);
    }
    function setByPath(obj, pathParts, value) {
        let cur = obj;
        for (let i = 0; i < pathParts.length - 1; i++) {
            const k = pathParts[i];
            if (cur[k] == null || typeof cur[k] !== 'object') cur[k] = {};
            cur = cur[k];
        }
        cur[pathParts[pathParts.length - 1]] = value;
    }



    function parseBindings(attr) {
        const result = {};
        let current = '';
        let depth = 0;

        for (let i = 0; i < attr.length; i++) {
            const char = attr[i];

            if (char === ',' && depth === 0) {
                processBinding(current, result);
                current = '';
            } else {
                if (char === '[' || char === '{') depth++;
                if (char === ']' || char === '}') depth--;
                current += char;
            }
        }

        if (current) processBinding(current, result);

        return result;
    }

    function parseForeachBinding(str) {
        let arrayKey = str;
        let alias = null;
        if (str && str.trim().startsWith('[')) {
            const configStr = str.trim().replace(/^\[|\]$/g, '');
            const parts = configStr.split(',').map(p => p.trim());
            parts.forEach(p => {
                const [k, v] = p.split(':').map(x => x.trim());
                if (k === 'data') arrayKey = v;
                if (k === 'as') alias = v;
            });
        }
        return { arrayKey, alias };
    }

    function processBinding(str, result) {
        const parts = str.split(':');
        if (parts.length >= 2) {
            const key = parts[0].trim();
            const val = parts.slice(1).join(':').trim();
            result[key] = val;
        }
    }

    function createReactiveState(initial) {
        const subscribers = {};

        function wrapArray(arr, propKey) {
            return new Proxy(arr, {
                get(target, prop, receiver) {
                    // Intercept mutating array methods
                    if (['push', 'splice', 'shift', 'unshift', 'pop', 'sort', 'reverse'].includes(prop)) {
                        return function (...args) {
                            const result = Array.prototype[prop].apply(target, args);
                            if (subscribers[propKey]) {
                                subscribers[propKey].forEach(cb => cb(target));
                            }
                            return result;
                        }
                    }
                    return Reflect.get(target, prop, receiver);
                },
                set(target, prop, value, receiver) {
                    const result = Reflect.set(target, prop, value, receiver);
                    if (subscribers[propKey]) {
                        subscribers[propKey].forEach(cb => cb(target));
                    }
                    return result;
                }
            });
        }

        const proxy = new Proxy(initial, {
            get(target, prop, receiver) {
                return Reflect.get(target, prop, receiver);
            },
            set(target, prop, value, receiver) {
                // If assigning an array, wrap it so mutations trigger updates
                if (Array.isArray(value)) {
                    value = wrapArray(value, prop);
                }
                const result = Reflect.set(target, prop, value, receiver);
                if (subscribers[prop]) {
                    subscribers[prop].forEach(cb => cb(value));
                }
                return result;
            }
        });

        // Wrap existing arrays in `initial` so they’re reactive too
        for (const key in initial) {
            if (Array.isArray(initial[key])) {
                proxy[key] = wrapArray(initial[key], key);
            }
        }

        function subscribe(key, fn) {
            if (!subscribers[key]) subscribers[key] = [];
            subscribers[key].push(fn);
        }

        return { state: proxy, subscribe };
    }

    function isInsideLoopOrWith(el) {
        return el.closest('[data-bind*="foreach:"]') || el.closest('[data-bind*="with:"]');
    }

    function renderForeach(container, arr, alias, template, arrayKey, state) {
        container.innerHTML = '';

        arr.forEach((item, index) => {
            const clone = template.cloneNode(true);

            // Tag this row with index & owner array
            clone.setAttribute('data-key', index);
            clone.setAttribute('data-foreach-owner', arrayKey);

            // Bind text/value fields
            const bindables = clone.querySelectorAll('[data-bind]');

            const supportedEvents = [
                'click', 'change', 'input', 'blur', 'focus',
                'keydown', 'keyup', 'keypress',
                'mouseenter', 'mouseleave', 'mouseover', 'mouseout',
                'dblclick', 'contextmenu',
                'mousedown', 'mouseup'
            ];

            bindables.forEach(el => {
                const bindInfo = parseBindings(el.getAttribute('data-bind'));
                for (let [bType, bKey] of Object.entries(bindInfo)) {
                    if (bType === 'text') {
                        el.textContent = item[bKey];
                    }
                    if (bType === 'value' && el instanceof HTMLInputElement) {
                        if (el.type === 'checkbox') {
                            el.checked = item[bKey];
                        } else {
                            el.value = item[bKey];
                        }
                    }

                    if (supportedEvents.includes(bType)) {
                        if (bKey === 'remove' || bKey === 'removeItem') {
                            el.addEventListener(bType, () => {
                                state[arrayKey].splice(index, 1);
                            });
                        } else if (typeof state[bKey] === 'function') {
                            el.addEventListener(bType, () => {
                                state[bKey](item, index, state[arrayKey]);
                            });
                        }
                    }
                }
            });

            container.appendChild(clone);
        });
    }

    function eventBinding(bindings, bindingsMap, el) {
        const supportedEvents = [
            'click', 'change', 'input', 'blur', 'focus',
            'keydown', 'keyup', 'keypress',
            'mouseenter', 'mouseleave', 'mouseover', 'mouseout',
            'dblclick', 'contextmenu',
            'mousedown', 'mouseup'
        ];

        supportedEvents.forEach(eventType => {

            if (bindings[eventType]) {
                const handlerName = resolveBindingKey(bindings[eventType]);
                if (!handlerName) return;

                bindingsMap.push({
                    el,
                    type: eventType,
                    key: handlerName,
                    bindings: bindings
                });
            }
        });
    }

    function applyEvent(el, key, type, state, update, subscribe, componentEl) {
        // ✅ Handle basic events like click, input, change
        const supportedEvents = [
            'click', 'change', 'input', 'blur', 'focus',
            'keydown', 'keyup', 'keypress',
            'mouseenter', 'mouseleave', 'mouseover', 'mouseout',
            'dblclick', 'contextmenu',
            'mousedown', 'mouseup'
        ];

        // If element is inside foreach, skip direct binding – delegation will handle it
        if (el.closest('[data-foreach-owner]')) {
            return;
        }

        if (supportedEvents.includes(type)) {
            const handlerName = key;  // ✅ now "handleClick" or "handleHover"
            const ctx = componentEl.$ctx || {};

            if (typeof ctx[handlerName] === 'function') {
                el.addEventListener(type, ctx[handlerName]);
                return;
            }

            if (type === 'click') {
                if (key === 'remove' || key === 'removeItem') {
                    el.addEventListener('click', () => {
                        const parent = el.closest('[data-key][data-foreach-owner]');
                        if (!parent) return;

                        const index = parseInt(parent.getAttribute('data-key'), 10);
                        const stateKey = parent.getAttribute('data-foreach-owner');

                        if (!Array.isArray(state[stateKey])) return;

                        state[stateKey].splice(index, 1); // This triggers re-render via Proxy 
                    });
                    return;
                }


                // Fall back to user-defined click handler 
                const ctx = componentEl.$ctx || {};

                if (typeof ctx[key] === 'function') {
                    el.addEventListener('click', ctx[key]);
                } else {
                    if (!componentEl._pendingEvents) componentEl._pendingEvents = [];
                    componentEl._pendingEvents.push({
                        el,
                        type,
                        handlerName
                    });
                }

            } else {

                // Delay binding until ctx is available
                if (!componentEl._pendingEvents) componentEl._pendingEvents = [];
                componentEl._pendingEvents.push({
                    el,
                    type,
                    handlerName
                });
            }

            // console.log(componentEl._pendingEvents)

            return;
        }
    }

    function applyContext(data, state /*=component state*/, subscribe /*component-level subscribe*/) {
        // data: object from bindingsMap, expected to contain { el, type: 'context', key }
        if (!data || data.type !== 'context') return;
        const el = data.el;
        const key = data.key;

        // Use underlying object if present on top-level component state, otherwise create a plain object
        let underlying = state[key];
        if (typeof underlying !== 'object' || underlying === null) underlying = {};

        // local pub/sub for this context proxy
        const subs = {}; // subs[prop] = [fn,...]
        const ctxSubscribe = (prop, fn) => {
            if (!subs[prop]) subs[prop] = [];
            subs[prop].push(fn);
        };

        // Proxy that notifies its own subscribers
        const proxy = new Proxy(underlying, {
            set(target, prop, value) {
                const prev = target[prop];
                const res = Reflect.set(target, prop, value);
                // notify specific prop subscribers
                if (subs[prop]) subs[prop].forEach(fn => fn(value, prev));
                // notify wildcard subscribers
                if (subs['*']) subs['*'].forEach(fn => fn(prop, value, prev));
                return res;
            }
        });

        // Store the proxy back into component root state (so direct reading state[key] still works)
        state[key] = proxy;

        // Attach context descriptor onto the component element so descendants can find it
        el._context = {
            key,
            state: proxy,
            subscribe: ctxSubscribe
        };
    }

    function resolveTargetForBinding(el, rawKey, componentState) {
        // rawKey might be 'firstName' or 'layout.firstName' or 'cart.items.0'
        if (typeof rawKey !== 'string') return { targetState: componentState, pathParts: [rawKey] };

        const parts = rawKey.split('.').map(p => p.trim()).filter(Boolean);
        if (parts.length === 0) return { targetState: componentState, pathParts: [] };

        if (parts.length > 1) {
            // explicit context prefix: parts[0] is context name (look for nearest ancestor context with that name)
            const ctx = findAncestorContextByName(el, parts[0]);
            if (ctx) {
                return { targetState: ctx.state, pathParts: parts.slice(1), context: ctx };
            }
            // If prefix not found, fallback to trying to resolve as normal (no prefix)
        }

        // no explicit prefix OR prefix not found:
        // walk ancestors: if any context contains the property at top-level, use that (nearest first)
        const prop = parts[0];
        const anc = findAncestorContexts(el);
        for (const ctx of anc) {
            try {
                // honest check: property exists (own or inherited)
                if (Object.prototype.hasOwnProperty.call(ctx.state, prop)) {
                    return { targetState: ctx.state, pathParts: parts, context: ctx };
                }
            } catch (e) { /* ignore malformed ctx.state */ }
        }

        // Not found in any ancestor context; if component-level state has it, use that:
        if (Object.prototype.hasOwnProperty.call(componentState, prop)) {
            return { targetState: componentState, pathParts: parts, context: null };
        }

        // Last resort: put it into the nearest ancestor context if any; otherwise into componentState
        if (anc.length > 0) return { targetState: anc[0].state, pathParts: parts, context: anc[0] };
        return { targetState: componentState, pathParts: parts, context: null };
    }

    function contextBinding(bindings, ctx, initialState, el, bindingsMap) {
        if (bindings.context) {
            const contextKey = bindings.context.trim();


            // Create new sub-context for this component
            if (!(contextKey in initialState)) {
                initialState[contextKey] = {};
            }

            // Attach marker
            el.setAttribute("data-context-owner", contextKey);

            // Register in map
            bindingsMap.push({
                el,
                type: "context",
                key: contextKey,
                bindings
            });
        } else if (bindings.component) {
            // 🚀 Even if no explicit `context:`, we still auto-generate
            const compName = bindings.component;
            const defaultKey = compName.charAt(0).toLowerCase() + compName.slice(1);

            if (!(defaultKey in initialState)) {
                initialState[defaultKey] = {};
            }

            el.setAttribute("data-context-owner", defaultKey);

            bindingsMap.push({
                el,
                type: "context",
                key: defaultKey,
                bindings
            });
        }
    }

    /*
    function applyContext(el, key, type, state, update, subscribe) {
        if (type === "component" || type === "context") {
            // Ensure subState exists (but do not force into parent state automatically)
            let subState = {};

            // Wrap in proxy for reactivity
            const proxy = new Proxy(subState, {
                set(target, prop, value) {
                    const result = Reflect.set(target, prop, value);
                    update();
                    return result;
                }
            });

            // Store context proxy separately (not in parent state by default)
            el._context = { key, state: proxy };

            // If someone does `import:loginContext`, they’ll get this proxy
            // But internally, the component just uses its own local scope
        }
    }
    */

    function foreachBinding(bindings, el, initialState, ctx) {
        if (bindings.foreach) {
            let arrayKey = bindings.foreach;
            let alias = null;

            if (arrayKey.startsWith('[')) {
                try {
                    const configStr = arrayKey.trim().replace(/^\[|\]$/g, '');
                    const configParts = configStr.split(',').map(p => p.trim());
                    configParts.forEach(part => {
                        const [k, v] = part.split(':').map(x => x.trim());
                        if (k === 'data') arrayKey = v;
                        if (k === 'as') alias = v;
                    });
                } catch (err) {
                    console.warn('Invalid foreach syntax', arrayKey);
                }
            }

            const children = Array.from(el.children);
            const template = children[0].cloneNode(true);

            const parsedArray = children.map(child => {
                const obj = {};
                const deepBindables = child.querySelectorAll('[data-bind]');
                deepBindables.forEach(bindable => {
                    const bindInfo = parseBindings(bindable.getAttribute('data-bind'));
                    for (let [bType, bKey] of Object.entries(bindInfo)) {
                        if (bType === 'text') {
                            obj[bKey] = bindable.textContent.trim();
                        }
                        if (bType === 'value' && bindable instanceof HTMLInputElement) {
                            obj[bKey] = bindable.type === 'checkbox'
                                ? bindable.checked
                                : bindable.value;
                        }
                    }
                });
                return obj;
            });

            // Reactive Proxy
            initialState[arrayKey] = new Proxy(parsedArray, {
                get(target, prop, receiver) {
                    if (['push', 'splice', 'shift', 'unshift', 'pop', 'sort', 'reverse'].includes(prop)) {
                        return function (...args) {
                            const result = Array.prototype[prop].apply(target, args);
                            renderForeach(el, target, alias, template, arrayKey, initialState, ctx);
                            return result;
                        };
                    }
                    return Reflect.get(target, prop, receiver);
                },
                set(target, prop, value, receiver) {
                    const result = Reflect.set(target, prop, value, receiver);
                    renderForeach(el, target, alias, template, arrayKey, initialState, ctx);
                    return result;
                }
            });

            // Initial render
            renderForeach(el, initialState[arrayKey], alias, template, arrayKey, initialState, ctx);
        }
    }

    function submitBinding(bindings, bindingsMap, el) {
        if (bindings.submit) {
            bindingsMap.push({
                el,
                type: 'submit',
                key: bindings.submit, // either 'ajax' or 'default'
                bindings: bindings,
            });
        }
    }

    function attributeBinding(bindings, initialState, el, bindingsMap) {
        if (bindings.attr) {
            try {
                const cleaned = bindings.attr.trim().replace(/^\[|\]$/g, '').trim(); // removes [ ]
                const regex = /([\w.]+)\s*=>\s*([\w-]+)/g; // left = stateKey, right = attrName
                let match;

                while ((match = regex.exec(cleaned)) !== null) {
                    const stateKey = match[1]; // ✅ state first
                    if (!(stateKey in initialState)) {
                        if (!isInsideLoopOrWith(el)) {
                            initialState[stateKey] = "";
                        }
                    }
                }

                bindingsMap.push({
                    el,
                    type: 'attr',
                    key: bindings.attr,
                    updateEvent: bindings.update || null,
                    bindings: bindings,
                });
            } catch (e) {
                console.warn('Invalid attr binding during initialization:', bindings.attr);
            }
        }
    }

    function classBinding(bindings, initialState, el, bindingsMap) {
        if (bindings.class) {
            try {
                const cleaned = bindings.class.trim().replace(/^\[|\]$/g, '').trim(); // removes [ ]
                const regex = /([\w.]+)\s*=>\s*([\w-]+)/g; // left = stateKey, right = className
                let match;

                while ((match = regex.exec(cleaned)) !== null) {
                    const stateKey = match[1]; // ✅ state comes first now
                    if (!(stateKey in initialState)) {
                        if (!isInsideLoopOrWith(el)) {
                            initialState[stateKey] = false;
                        }
                    }
                }

                bindingsMap.push({
                    el,
                    type: 'class',
                    key: bindings.class,
                    updateEvent: bindings.update || null,
                    bindings: bindings,
                });
            } catch (e) {
                console.warn('Invalid class binding during initialization:', bindings.class);
            }
        }
    }

    function htmlBinding(bindings, bindingsMap, el, initialState) {
        if (bindings.html) {
            bindingsMap.push({
                el,
                type: 'html',
                key: bindings.html,
                updateEvent: bindings.update || null,
                bindings: bindings,
            });

            if (!(bindings.html in initialState)) {
                if (!isInsideLoopOrWith(el)) {
                    initialState[bindings.html] = '';
                }
            }
        }
    }

    function visibleBinding(bindings, bindingsMap, el, initialState) {
        if (bindings.visible) {
            bindingsMap.push({
                el,
                type: 'visible',
                key: bindings.visible,
                updateEvent: bindings.update || null,
                bindings: bindings,
            });

            if (!(bindings.visible in initialState)) {
                if (!isInsideLoopOrWith(el)) {
                    initialState[bindings.visible] = true;
                }

            }
        }
    }

    function toggleBinding(bindings, bindingsMap, el, initialState) {
        if (bindings.toggle) {
            bindingsMap.push({
                el,
                type: 'toggle',
                key: bindings.all,
                updateEvent: bindings.update || null,
                bindings: bindings,
            });

            if (!(bindings.all in initialState)) {
                if (!isInsideLoopOrWith(el)) {
                    initialState[bindings.all] = [];
                }
            }
        }
    }

    /*
    function applyText(el, key, type, state, subscribe) {
        if (type === 'text') {
            el.textContent = state[key];

            subscribe(key, val => {
                el.textContent = Array.isArray(val) ? val.join(', ') : val;
            });
            return;
        }
    }
    */

    function applyText(el, rawKey, type, componentState, componentSubscribe) {
        // componentSubscribe is your existing createReactiveState subscribe
        const resolved = resolveTargetForBinding(el, rawKey, componentState);
        const { targetState, pathParts, context } = resolved;

        // read once:
        const initial = getByPath(targetState, pathParts);
        el.textContent = initial == null ? '' : String(initial);

        // subscribe: prefer context-local subscribe if present, otherwise fall back to componentSubscribe
        if (context && typeof context.subscribe === 'function') {
            // subscribe to that exact property
            const prop = pathParts[0]; // top-level property for context-case
            context.subscribe(prop, (val) => {
                el.textContent = val == null ? '' : String(val);
            });
        } else {
            // fallback: if targetState is the componentState, use componentSubscribe(key)
            const key = pathParts[0];
            if (typeof componentSubscribe === 'function') {
                componentSubscribe(key, val => { el.textContent = val == null ? '' : String(val); });
            }
        }
    }


    function textBinding(bindings, bindingsMap, el, initialState) {
        let { text } = bindings;

        if (text) {
            bindingsMap.push({
                el,
                type: 'text',
                key: text,
                bindings: bindings
            });
            if (!(text in initialState)) {
                const textVal = el.textContent.trim();
                if (textVal) {
                    if (!isInsideLoopOrWith(el)) {
                        initialState[text] = textVal;
                    }
                } else {
                    if (!isInsideLoopOrWith(el)) {
                        initialState[text] = '';
                    }
                }
            }
        }
    }

    /*
    function applyValue(el, key, type, state, updateEvent, subscribe, keyUsageCount) {

        if (type === 'value' && el instanceof HTMLInputElement) {
            const inputType = el.type;
            const fallbackEvent = inputType === 'checkbox' || inputType === 'radio' ? 'change' : 'input';
            const eventToUse = updateEvent || fallbackEvent;

            if (inputType === 'checkbox') {
                const checkboxValue = el.value;
                const isGrouped = Array.isArray(state[key]) || keyUsageCount[key] > 1;

                if (isGrouped) {
                    if (!Array.isArray(state[key])) {
                        state[key] = [];
                    }

                    el.checked = state[key].includes(checkboxValue);

                    el.addEventListener(eventToUse, () => {
                        const current = new Set(state[key]);

                        if (el.checked) {
                            current.add(checkboxValue);
                        } else {
                            current.delete(checkboxValue);
                        }

                        state[key] = [...current];
                    });

                    subscribe(key, val => {
                        el.checked = val.includes(checkboxValue);
                    });
                } else {
                    el.checked = !!state[key];

                    el.addEventListener(eventToUse, () => {
                        state[key] = el.checked;
                    });

                    subscribe(key, val => {
                        el.checked = !!val;
                    });
                }

                return;
            }

            if (inputType === 'radio') {
                const radioValue = el.value;

                // Set initially checked radio if not already set
                if (!(key in state) && el.checked) {
                    state[key] = radioValue;
                }

                // Reflect current state into DOM
                el.checked = state[key] === radioValue;

                // When user selects a radio, update state
                el.addEventListener(eventToUse, () => {
                    if (el.checked) {
                        state[key] = radioValue;
                    }
                });

                // When state changes, update which radio is checked
                subscribe(key, val => {
                    el.checked = val === radioValue;
                });

                return;
            }

            // For text/number/etc
            const min = el.hasAttribute('min') ? parseFloat(el.getAttribute('min')) : null;
            const max = el.hasAttribute('max') ? parseFloat(el.getAttribute('max')) : null;

            el.value = state[key];

            el.addEventListener(eventToUse, e => {
                let val = e.target.value;

                if (inputType === 'number') {
                    val = parseFloat(val);
                    if (!isNaN(val)) {
                        if (min !== null && val < min) val = min;
                        if (max !== null && val > max) val = max;
                    } else {
                        val = '';
                    }
                }

                state[key] = val;
            });

            subscribe(key, val => {
                if (el.value !== val) el.value = val;
            });
        }
    }
    */
    function applyValue(el, rawKey, type, componentState, updateEvent, componentSubscribe) {
        const resolved = resolveTargetForBinding(el, rawKey, componentState);
        const { targetState, pathParts, context } = resolved;
        const key = pathParts[pathParts.length - 1];

        // initial set
        const v = getByPath(targetState, pathParts);
        if (el.type === 'checkbox') {
            el.checked = !!v;
        } else {
            if (el.value !== String(v ?? '')) el.value = v == null ? '' : String(v);
        }

        // subscribe changes to target
        if (context && typeof context.subscribe === 'function') {
            context.subscribe(key, val => {
                if (el.type === 'checkbox') el.checked = !!val;
                else if (el.value !== String(val ?? '')) el.value = val == null ? '' : String(val);
            });
        } else if (typeof componentSubscribe === 'function') {
            componentSubscribe(key, val => {
                if (el.type === 'checkbox') el.checked = !!val;
                else if (el.value !== String(val ?? '')) el.value = val == null ? '' : String(val);
            });
        }

        // write back to the resolved target when user types/selects
        const writeBack = (val) => {
            // if nested path, use setByPath which will create objects on the way
            setByPath(targetState, pathParts, val);
            // proxy's set trap will call context.subscribe and trigger UI updates
        };

        const evt = updateEvent || (el.type === 'checkbox' || el.type === 'radio' ? 'change' : 'input');
        el.addEventListener(evt, e => {
            let newVal;
            if (el.type === 'checkbox') newVal = el.checked;
            else if (el.type === 'number') newVal = parseFloat(el.value);
            else newVal = el.value;
            writeBack(newVal);
        });
    }


    function valueBinding(bindings, bindingsMap, el, keyUsageCount, initialState) {

        let { value, update } = bindings;

        if (value) {
            bindingsMap.push({
                el,
                type: 'value',
                key: value,
                updateEvent: update || null,
                bindings: bindings
            });
            keyUsageCount[value] = (keyUsageCount[value] || 0) + 1;

            // Initialize value
            if (!(value in initialState)) {
                let val;
                if (el.type === 'checkbox') {
                    val = keyUsageCount[value] > 1 ? [] : !!el.checked;
                } else if (el.type === 'radio') {
                    if (el.checked) val = el.value;

                } else if (el.type === 'number') {
                    const num = parseFloat(el.value);
                    val = isNaN(num) ? '' : num;
                } else {
                    val = el.value;
                }

                if (!isInsideLoopOrWith(el)) {
                    initialState[value] = val;
                }

            } else {
                // If this key already came from a text binding but we have an input with value
                // → override it according to your priority
                if (el.value && el.value.trim()) {
                    if (!isInsideLoopOrWith(el)) {
                        initialState[value] = el.value;
                    }
                }
            }
        }
    }

    function applySelect(el, key, type, state, update, subscribe) {
        // ✅ SELECT element
        if (type === 'value' && el instanceof HTMLSelectElement) {
            const eventToUse = update || 'change';

            el.value = state[key];

            el.addEventListener(eventToUse, e => {
                state[key] = e.target.value;
            });

            subscribe(key, val => {
                if (el.value !== val) el.value = val;
            });

            return;
        }
    }

    function applyTextArea(el, key, type, state, update, subscribe,) {
        // ✅ TEXTAREA element
        if (type === 'value' && el instanceof HTMLTextAreaElement) {
            const eventToUse = update || 'input';

            el.value = state[key];

            el.addEventListener(eventToUse, e => {
                state[key] = e.target.value;
            });

            subscribe(key, val => {
                if (el.value !== val) el.value = val;
            });

            return;
        }
    }

    function applyFocused(el, key, type, state, update, subscribe) {
        if (type === 'focused') {
            // Update state when user focuses or blurs input
            el.addEventListener('focus', () => {
                state[key] = true;
            });
            el.addEventListener('blur', () => {
                state[key] = false;
            });

            // Reactively apply focus based on state
            subscribe(key, val => {
                if (val && document.activeElement !== el) {
                    el.focus();
                }
                // Optional: remove focus when false
                // else if (!val && document.activeElement === el) {
                //     el.blur();
                // }
            });

            return;
        }
    }

    function applyVisibile(el, key, type, state, update, subscribe) {
        if (type === 'visible') {
            const applyVisibility = (val) => {
                el.style.display = val ? '' : 'none';
            };

            // Initial
            applyVisibility(state[key]);

            // React on change
            subscribe(key, val => {
                applyVisibility(val);
            });

            return;
        }
    }

    function applyReadOnly(el, key, type, state, update, subscribe) {
        if (type === 'readonly') {
            el.readOnly = !!state[key];
            subscribe(key, val => {
                el.readOnly = !!val;
            });
        }
    }

    function applyDisabled(el, key, type, state, update, subscribe) {
        if (type === 'disabled') {
            el.disabled = !!state[key];
            subscribe(key, val => {
                el.disabled = !!val;
            });
        }
    }

    function applyCheckboxToggle(el, key, type, state, update, subscribe, componentEl) {
        // ✅ Select-All checkbox logic
        if (type === 'toggle' && el instanceof HTMLInputElement && el.type === 'checkbox') {
            el.addEventListener('change', () => {
                const groupCheckboxes = componentEl.querySelectorAll(`input[type="checkbox"][data-bind*="value:${key}"]`);
                const values = Array.from(groupCheckboxes).map(c => c.value);
                state[key] = el.checked ? values : [];
            });

            subscribe(key, val => {
                const groupCheckboxes = componentEl.querySelectorAll(`input[type="checkbox"][data-bind*="value:${key}"]`);
                const values = Array.from(groupCheckboxes).map(c => c.value);
                el.checked = Array.isArray(val) && values.every(v => val.includes(v));
            });
        }
    }

    function applyHtml(el, key, type, state, update, subscribe) {
        if (type === 'html') {
            // Initial render
            el.innerHTML = state[key];

            // Subscribe to future changes
            subscribe(key, val => {
                el.innerHTML = val;
            });

            return;
        }
    }

    function applyClass(el, key, type, state, update, subscribe) {
        if (type === 'class') {
            try {
                const cleaned = key.trim().replace(/^\[|\]$/g, '').trim();
                const pairs = cleaned.split(',').map(pair => pair.trim());

                for (const pair of pairs) {
                    const [stateKey, className] = pair.split(/\s*=>\s*/); // ✅ swapped

                    if (!stateKey || !className) continue;

                    // Apply initial state
                    el.classList.toggle(className, !!state[stateKey]);

                    // Subscribe for updates
                    subscribe(stateKey, (val) => {
                        el.classList.toggle(className, !!val);
                    });
                }
            } catch (e) {
                console.warn('Invalid class binding:', key);
            }

            return;
        }
    }

    function applyAttribute(el, key, type, state, update, subscribe) {
        if (type === 'attr') {
            try {
                const cleaned = key.trim().replace(/^\[|\]$/g, '').trim();
                const pairs = cleaned.split(',').map(pair => pair.trim());

                for (const pair of pairs) {
                    const [stateKey, attrName] = pair.split(/\s*=>\s*/); // ✅ swapped

                    if (!stateKey || !attrName) continue;

                    // Initial set
                    el.setAttribute(attrName, state[stateKey] ?? '');

                    // Reactive
                    subscribe(stateKey, val => {
                        el.setAttribute(attrName, val ?? '');
                    });
                }
            } catch (e) {
                console.warn('Invalid attr binding:', key);
            }

            return;
        }
    }

    function applySubmit(el, key, type, bindings, componentEl) {
        if (type === 'submit' && el instanceof HTMLFormElement) {
            const behavior = key.trim(); // ajax or default
            const swap = bindings.swap?.trim() || 'innerHTML';

            if (behavior === 'ajax') {
                const formId = el.id || `form-${Math.random().toString(36).slice(2)}`;
                el.id = formId;

                const parentComponent = componentEl;
                const targetId = parentComponent.id || `target-${Math.random().toString(36).slice(2)}`;
                parentComponent.id = targetId;

                const ctx = componentEl.$ctx || {};

                enhanceForm({
                    formId,
                    targetId,
                    swap,
                    beforeSend: ctx.beforeSend,
                    onSuccess: ctx.onSuccess,
                    onError: ctx.onError
                });
            }

            // If "default", do nothing – browser will handle it
            return;
        }
    }

    function applyForeach(el, key, type, state, update, subscribe) {
        if (type === 'foreach') {
            const items = state[data.key];
            const parent = el;
            const templateNodes = Array.from(parent.children);

            // Just tag items with $index and $item (optional for future use)
            // console.log(items);

            parent.innerHTML = ''; // clear

            items.forEach((item, index) => {
                const clone = templateNodes[index]?.cloneNode(true);
                if (!clone) return;
                const innerBindables = clone.querySelectorAll('[data-bind]');

                innerBindables.forEach(bindEl => {
                    const bindInfo = parseBindings(bindEl.getAttribute('data-bind'));
                    Object.entries(bindInfo).forEach(([bType, bKey]) => {
                        if (bType === 'text') {
                            bindEl.textContent = item[bKey];
                        }
                        if (bType === 'value' && bindEl instanceof HTMLInputElement) {
                            bindEl.value = item[bKey];
                            if (bindEl.type === 'checkbox') {
                                bindEl.checked = !!item[bKey];
                            }
                        }
                    });

                    /*
                    Object.entries(bindInfo).forEach(([bType, bKey]) => {
                        let finalKey = bKey;

                        // Support alias: "alias.someProp" → item.someProp
                        if (alias && finalKey.startsWith(alias + '.')) {
                            finalKey = finalKey.replace(alias + '.', '');
                        }

                        if (bType === 'text') {
                            bindEl.textContent = item[finalKey];
                        }
                        if (bType === 'value' && bindEl instanceof HTMLInputElement) {
                            bindEl.value = item[finalKey];
                            if (bindEl.type === 'checkbox') {
                                bindEl.checked = !!item[finalKey];
                            }
                        }
                    });
                    */

                });

                parent.appendChild(clone);
            });

            return;
        }
    }


    function applyExpose(el, key, type, state, update, subscribe) {
        if (type === "expose") {
            const exposeMap = data.exposeMap;  // will always exist now
            if (!exposeMap || Object.keys(exposeMap).length === 0) return;

            const parentKey = el.closest("[data-with-owner]")?.getAttribute("data-with-owner");
            if (!parentKey) return;

            const parentObj = initialState[parentKey];

            Object.entries(exposeMap).forEach(([childProp, parentProp]) => {
                Object.defineProperty(parentObj, parentProp, {
                    get: () => state[childProp],
                    set: (val) => { state[childProp] = val; },
                    enumerable: true,
                    configurable: true
                });
            });
            return;
        }
    }

    function initializeStateBindings(componentEl, context = {}) {
        const ctx = componentEl.$ctx || context || {};
        const bindingsMap = [];
        const initialState = {};
        const keyUsageCount = {};

        const allBindings = document.querySelectorAll('[data-bind]');
        const bindables = [];

        allBindings.forEach(el => {
            const nearestComponent = el.closest('[data-bind*="component:"]');

            if (nearestComponent === componentEl) {
                bindables.push(el); // ✅ Inside this specific component
            } else if (!nearestComponent) {
                console.warn('⚠️ Found data-bind element outside any component:', el);
            }
        });

        // First pass: collect bindings and count usage        
        bindables.forEach(el => {
            const bindings = parseBindings(el.getAttribute('data-bind'));

            textBinding(bindings, bindingsMap, el, initialState);
            valueBinding(bindings, bindingsMap, el, keyUsageCount, initialState);
            toggleBinding(bindings, bindingsMap, el, initialState);
            visibleBinding(bindings, bindingsMap, el, initialState);
            htmlBinding(bindings, bindingsMap, el, initialState);
            classBinding(bindings, initialState, el, bindingsMap);
            attributeBinding(bindings, initialState, el, bindingsMap);
            submitBinding(bindings, bindingsMap, el);
            eventBinding(bindings, bindingsMap, el);
            contextBinding(bindings, ctx, initialState, el, bindingsMap);
            // exportBinding(bindings, el, bindingsMap)
            // foreachBinding(bindings, el, initialState, ctx);
        });

        const { state, subscribe } = createReactiveState(initialState);
        componentEl.$state = state;

        // Second pass: bind all
        bindingsMap.forEach((data) => {

            let { el, updateEvent, bindings } = data;

            Object.entries(bindings).forEach(([type, key]) => {
                applyText(el, key, type, state, subscribe)
                applyValue(el, key, type, state, updateEvent, subscribe, keyUsageCount)
                applySelect(el, key, type, state, updateEvent, subscribe)
                applyTextArea(el, key, type, state, updateEvent, subscribe);
                applyFocused(el, key, type, state, updateEvent, subscribe)
                applyVisibile(el, key, type, state, updateEvent, subscribe)
                applyReadOnly(el, key, type, state, updateEvent, subscribe)
                applyDisabled(el, key, type, state, updateEvent, subscribe)
                applyCheckboxToggle(el, key, type, state, updateEvent, subscribe, componentEl)
                applyHtml(el, key, type, state, updateEvent, subscribe)
                applyClass(el, key, type, state, updateEvent, subscribe)
                applyAttribute(el, key, type, state, updateEvent, subscribe)
                applySubmit(el, key, type, bindings, componentEl)
                applyEvent(el, key, type, state, updateEvent, subscribe, componentEl)
                applyContext(data, state, subscribe)


                // applyForeach(el, key, type, state, updateEvent, subscribe)
            });

            // applyExport(data, state, initialState);

        });
    }

    window.jsRibbonState = {
        init: initializeStateBindings,
        enhanceForm,            // ← add these
        applySwap
    };
})();
