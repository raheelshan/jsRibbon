


        // jsRibbon.component('ClickCheck', ($state) => {


        //     const handleClick = (data) => {
        //         console.log($state.firstName)
        //     };

        //     const handleMouseEnter = () => {
        //         // console.log('Mouse entered');
        //     }

        //     console.log('regstered');

        //     return { handleClick, handleMouseEnter };
        // });


        // jsRibbon.component('FormCheck', () => {
        //     const beforeSend = (formEl) => {
        //         console.log("⏳ Submitting form...", formEl);
        //     };

        //     const onSuccess = (result) => {
        //         console.log("✅ Success response", result);
        //     };

        //     const onError = (error, status) => {
        //         console.error("❌ Error", status, error);
        //     };

        //     return { beforeSend, onSuccess, onError };
        // });

        // setTimeout(() => {
        //     document.getElementById('dynamic-container').innerHTML = `
        //         <div data-bind="component:Dashboard">

        //         </div>
        //     `
        // }, 5000)

        // setTimeout(() => {

        //     document.getElementById('container').innerHTML = `<input data-bind="value: age" value="21" /> Your age: <span data-bind="text: age"> </span>`

        // }, 2000);

        // setTimeout(() => {
        // let el = document.getElementById('container')
        // jsRibbon.unregister(el);

        // jsRibbon.reset();

        // }, 7000);
        // setTimeout(() => {
        //     console.log(jsRibbon.getComponents())
        // }, 1000);


        // jsRibbon.reset(); // force rescan of DOM
